BrainWaveOSC 0.8 for Windows

- Run the 'BrainWaveOSC.exe' application (should work for most up to date Windows systems)
- If there is an error message about a missing "MSVCP100.dll", you need to download the 'Microsoft Visual C++ 2010 Redistributable Package' from here: http://www.microsoft.com/en-au/download/details.aspx?id=5555